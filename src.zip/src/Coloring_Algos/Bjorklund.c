#ifndef BJORKLUND_C
#define BJORKLUND_C
#include <../Data_Structures/c/GraphALL.c>
#endif