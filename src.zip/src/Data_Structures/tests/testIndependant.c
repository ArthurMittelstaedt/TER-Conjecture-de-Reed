#include "../c/GraphCollection.c"

int main(void) {
    GraphALL* g = Independant(2);
    printGraphALL(g);
}